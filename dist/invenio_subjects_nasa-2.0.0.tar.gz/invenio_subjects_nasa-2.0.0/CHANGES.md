# Changes

v2.0.0 (released 2024-02-07)

- Add GitHub actions for tests and pypi deployment
- Add Makefile and update setup.cfg and setup.py
- Update controlled vocabulary to 2024-02-07
- remove unused files and dependencies
- Add support for InvenioRDM v12.0.0
- Update license to the package
- Add tests for the package
- Update requirements
- sort terms by id

v1.1.2 (released 2022-08-18)

- Initial public release.
